import static org.junit.Assert.assertEquals;

import org.junit.Test;

import components.map.Map;
import components.map.Map.Pair;

/**
 * JUnit test fixture for {@code Map<String, String>}'s constructor and kernel
 * methods.
 *
 * @author Nathan Johnson and Aidan Dilsavor
 *
 */
public abstract class MapTest {

    /**
     * Invokes the appropriate {@code Map} constructor for the implementation
     * under test and returns the result.
     *
     * @return the new map
     * @ensures constructorTest = {}
     */
    protected abstract Map<String, String> constructorTest();

    /**
     * Invokes the appropriate {@code Map} constructor for the reference
     * implementation and returns the result.
     *
     * @return the new map
     * @ensures constructorRef = {}
     */
    protected abstract Map<String, String> constructorRef();

    /**
     *
     * Creates and returns a {@code Map<String, String>} of the implementation
     * under test type with the given entries.
     *
     * @param args
     *            the (key, value) pairs for the map
     * @return the constructed map
     * @requires <pre>
     * [args.length is even]  and
     * [the 'key' entries in args are unique]
     * </pre>
     * @ensures createFromArgsTest = [pairs in args]
     */
    private Map<String, String> createFromArgsTest(String... args) {
        assert args.length % 2 == 0 : "Violation of: args.length is even";
        Map<String, String> map = this.constructorTest();
        for (int i = 0; i < args.length; i += 2) {
            assert !map.hasKey(args[i]) : ""
                    + "Violation of: the 'key' entries in args are unique";
            map.add(args[i], args[i + 1]);
        }
        return map;
    }

    /**
     *
     * Creates and returns a {@code Map<String, String>} of the reference
     * implementation type with the given entries.
     *
     * @param args
     *            the (key, value) pairs for the map
     * @return the constructed map
     * @requires <pre>
     * [args.length is even]  and
     * [the 'key' entries in args are unique]
     * </pre>
     * @ensures createFromArgsRef = [pairs in args]
     */
    private Map<String, String> createFromArgsRef(String... args) {
        assert args.length % 2 == 0 : "Violation of: args.length is even";
        Map<String, String> map = this.constructorRef();
        for (int i = 0; i < args.length; i += 2) {
            assert !map.hasKey(args[i]) : ""
                    + "Violation of: the 'key' entries in args are unique";
            map.add(args[i], args[i + 1]);
        }
        return map;
    }

    @Test
    public final void testNoArgumentConstructor() {
        /*
         * Set up variables and call method under test
         */
        Map<String, String> map = this.constructorTest();
        Map<String, String> mapExpected = this.constructorRef();
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(mapExpected, map);
    }

    @Test
    public final void testAddEmpty() {
        /*
         * Set up variables and call method under test
         */
        String key1 = "hi";
        String value1 = "hello";
        Map<String, String> map = this.constructorTest();
        Map<String, String> mapExpected = this.createFromArgsRef(key1, value1);
        map.add(key1, value1);

        /*
         * Assert that values of variables match expectations
         */
        assertEquals(mapExpected, map);
    }

    @Test
    public final void testAddNotEmpty() {
        /*
         * Set up variables and call method under test
         */
        String key1 = "hi";
        String value1 = "hello";
        String key2 = "howdy";
        String value2 = "hola";
        String key3 = "sup";
        String value3 = "how's it going";
        Map<String, String> map = this.createFromArgsTest(key1, value1, key2,
                value2);
        Map<String, String> mapExpected = this.createFromArgsRef(key1, value1,
                key2, value2, key3, value3);
        map.add(key3, value3);

        /*
         * Assert that values of variables match expectations
         */
        assertEquals(mapExpected, map);
    }

    @Test
    public final void testRemoveOne() {
        /*
         * Set up variables and call method under test
         */
        String key1 = "hi";
        String value1 = "hello";

        Map<String, String> map = this.createFromArgsTest(key1, value1);
        Map<String, String> mapExpected = this.constructorRef();
        map.remove(key1);

        /*
         * Assert that values of variables match expectations
         */
        assertEquals(mapExpected, map);
    }

    @Test
    public final void testRemoveMoreThanOne() {
        /*
         * Set up variables and call method under test
         */
        String key1 = "hi";
        String value1 = "hello";
        String key2 = "howdy";
        String value2 = "hola";
        String key3 = "sup";
        String value3 = "how's it going";
        Map<String, String> map = this.createFromArgsTest(key1, value1, key2,
                value2, key3, value3);
        Map<String, String> mapExpected = this.createFromArgsRef(key1, value1,
                key2, value2);
        map.remove(key3);

        /*
         * Assert that values of variables match expectations
         */
        assertEquals(mapExpected, map);
    }

    @Test
    public final void testRemoveAnyMoreThanOne() {
        /*
         * Set up variables and call method under test
         */
        String key1 = "hi";
        String value1 = "hello";
        String key2 = "howdy";
        String value2 = "hola";
        String key3 = "sup";
        String value3 = "how's it going";
        Map<String, String> map = this.createFromArgsTest(key1, value1, key2,
                value2, key3, value3);
        Map<String, String> mapExpected = this.createFromArgsRef(key1, value1,
                key2, value2, key3, value3);
        Pair<String, String> pair = map.removeAny();
        Pair<String, String> pairExpected = mapExpected.remove(pair.key());

        /*
         * Assert that values of variables match expectations
         */
        assertEquals(mapExpected, map);
        assertEquals(pairExpected, pair);
    }

    @Test
    public final void testRemoveAnyOne() {
        /*
         * Set up variables and call method under test
         */
        String key1 = "hi";
        String value1 = "hello";

        Map<String, String> map = this.createFromArgsTest(key1, value1);
        Map<String, String> mapExpected = this.createFromArgsRef(key1, value1);
        Pair<String, String> pair = map.removeAny();
        Pair<String, String> pairExpected = mapExpected.remove(pair.key());

        /*
         * Assert that values of variables match expectations
         */
        assertEquals(mapExpected, map);
        assertEquals(pairExpected, pair);
    }

    //value, haskey, size

    @Test
    public final void testValueOne() {
        /*
         * Set up variables and call method under test
         */
        String key1 = "hi";
        String value1 = "hello";

        Map<String, String> map = this.createFromArgsTest(key1, value1);
        Map<String, String> mapExpected = this.createFromArgsRef(key1, value1);
        String valueExpected = map.value(key1);

        /*
         * Assert that values of variables match expectations
         */
        assertEquals(mapExpected, map);
        assertEquals(valueExpected, value1);
    }

    @Test
    public final void testValueMoreThanOne() {
        /*
         * Set up variables and call method under test
         */
        String key1 = "hi";
        String value1 = "hello";
        String key2 = "howdy";
        String value2 = "hola";
        String key3 = "sup";
        String value3 = "how's it going";
        Map<String, String> map = this.createFromArgsTest(key1, value1, key2,
                value2, key3, value3);
        Map<String, String> mapExpected = this.createFromArgsRef(key1, value1,
                key2, value2, key3, value3);

        String valueExpected1 = map.value(key1);
        String valueExpected2 = map.value(key2);
        String valueExpected3 = map.value(key3);

        /*
         * Assert that values of variables match expectations
         */
        assertEquals(mapExpected, map);
        assertEquals(valueExpected1, value1);
        assertEquals(valueExpected2, value2);
        assertEquals(valueExpected3, value3);
    }

    @Test
    public final void testHasKeyOneTrue() {
        /*
         * Set up variables and call method under test
         */
        String key1 = "hi";
        String value1 = "hello";

        Map<String, String> map = this.createFromArgsTest(key1, value1);
        Map<String, String> mapExpected = this.createFromArgsRef(key1, value1);
        boolean keyOne = map.hasKey(key1);

        /*
         * Assert that values of variables match expectations
         */
        assertEquals(mapExpected, map);
        assertEquals(true, keyOne);
    }

    @Test
    public final void testHasKeyMoreThanOneTrue() {
        /*
         * Set up variables and call method under test
         */
        String key1 = "hi";
        String value1 = "hello";
        String key2 = "howdy";
        String value2 = "hola";
        String key3 = "sup";
        String value3 = "how's it going";
        Map<String, String> map = this.createFromArgsTest(key1, value1, key2,
                value2, key3, value3);
        Map<String, String> mapExpected = this.createFromArgsRef(key1, value1,
                key2, value2, key3, value3);

        boolean keyOne = map.hasKey(key1);
        boolean keyTwo = map.hasKey(key2);
        boolean keyThree = map.hasKey(key3);

        /*
         * Assert that values of variables match expectations
         */
        assertEquals(mapExpected, map);
        assertEquals(keyOne, true);
        assertEquals(keyTwo, true);
        assertEquals(keyThree, true);
    }

    @Test
    public final void testHasKeyFalse() {
        /*
         * Set up variables and call method under test
         */
        String key1 = "hi";
        String value1 = "hello";
        String key2 = "HELP";

        Map<String, String> map = this.createFromArgsTest(key1, value1);
        Map<String, String> mapExpected = this.createFromArgsRef(key1, value1);
        boolean keyTwo = map.hasKey(key2);

        /*
         * Assert that values of variables match expectations
         */
        assertEquals(mapExpected, map);
        assertEquals(false, keyTwo);
    }

    @Test
    public final void testSizeOne() {
        /*
         * Set up variables and call method under test
         */
        String key1 = "hi";
        String value1 = "hello";

        Map<String, String> map = this.createFromArgsTest(key1, value1);
        Map<String, String> mapExpected = this.createFromArgsRef(key1, value1);
        int size = map.size();
        int sizeExpected = 1;

        /*
         * Assert that values of variables match expectations
         */
        assertEquals(mapExpected, map);
        assertEquals(sizeExpected, size);
    }

    @Test
    public final void testSizeMoreThanOne() {
        /*
         * Set up variables and call method under test
         */
        String key1 = "hi";
        String value1 = "hello";
        String key2 = "howdy";
        String value2 = "hola";
        String key3 = "sup";
        String value3 = "how's it going";
        Map<String, String> map = this.createFromArgsTest(key1, value1, key2,
                value2, key3, value3);
        Map<String, String> mapExpected = this.createFromArgsRef(key1, value1,
                key2, value2, key3, value3);

        int size = map.size();
        int sizeExpected = 3;

        /*
         * Assert that values of variables match expectations
         */
        assertEquals(mapExpected, map);
        assertEquals(sizeExpected, size);
    }

    @Test
    public final void testSizeZero() {
        /*
         * Set up variables and call method under test
         */

        Map<String, String> map = this.createFromArgsTest();
        Map<String, String> mapExpected = this.createFromArgsRef();

        int size = map.size();
        int sizeExpected = 0;

        /*
         * Assert that values of variables match expectations
         */
        assertEquals(mapExpected, map);
        assertEquals(sizeExpected, size);
    }
}
