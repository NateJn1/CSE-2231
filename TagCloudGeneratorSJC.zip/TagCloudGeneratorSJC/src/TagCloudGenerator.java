import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;

/**
 * Takes an in-file, takes the amount of each word in the file, and then sorts
 * the words and displays their counts in a table.
 *
 * @author Aidan Dilsavor & Brandon Conley & Nathan Johnson
 *
 */
public final class TagCloudGenerator {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private TagCloudGenerator() {
    }

    /**
     * Entry<String, Integer> comparator class.
     **/

    private static class StringLT
            implements Comparator<Entry<String, Integer>> {
        @Override
        public int compare(Entry<String, Integer> o1,
                Entry<String, Integer> o2) {
            String lower1 = o1.getKey().toLowerCase();
            String lower2 = o2.getKey().toLowerCase();
            return lower1.compareTo(lower2);
        }
    }

    /**
     * Entry<String, Integer> comparator class.
     **/

    private static class MapPairLT
            implements Comparator<Entry<String, Integer>> {
        @Override
        public int compare(Entry<String, Integer> o1,
                Entry<String, Integer> o2) {
            return o2.getValue().compareTo(o1.getValue());
        }
    }

    /**
     * Returns the first "word" (maximal length string of characters not in
     * {@code separators}) or "separator string" (maximal length string of
     * characters in {@code separators}) in the given {@code text}.
     *
     * @param line
     *            The string to be ran through in order to find the next
     *            separator
     * @updates line
     *
     * @return the next word or separator in the given string (line)
     *
     *
     */
    private static String nextWordorSeparator(String line) {

        //Creating set of separators
        Set<Character> separators = new HashSet();
        separators.add(' ');
        separators.add('?');
        separators.add('/');
        separators.add('!');
        separators.add(',');
        separators.add('(');
        separators.add(')');
        separators.add('{');
        separators.add('}');
        separators.add('*');
        separators.add('&');
        separators.add('|');
        separators.add(':');
        separators.add(';');
        separators.add('"');
        separators.add('.');
        separators.add('_');
        separators.add('-');
        separators.add('\n');
        separators.add('\t');
        separators.add('\\');
        separators.add('[');
        separators.add(']');
        separators.add('\'');

        //Runs through line, stops at first separator in line
        String word = "";
        boolean condition = true;
        for (int i = 0; i < line.length() && condition; i++) {

            if (separators.contains(line.charAt(i))) {

                condition = false;
                word = line.substring(0, i);
            }
        }
        if (condition) {

            word = line;
        }
        return word;
    }

    /**
     * Stores each word from a text file into a map along with their respective
     * counts. Also stores each word in a queue that is sorted.
     *
     * @param map
     *            the map that will contain the words and their respective
     *            counts
     *
     * @param sorted
     *            the sorted queue that will contain the words
     *
     * @param inFile
     *            the text file used to create the map
     * @updates map
     * @updates sorted
     *
     * @ensures <pre>
     * map = #map *
     *   [all words and their respective counts within the text file]
     * sorted = #sorted *
     *   [all words within the text file in alphabetical order]
     * </pre>
     */
    private static void completeMap(Map<String, Integer> map,
            BufferedReader inFile) {

        //Continues until file is out of text
        Iterator<String> it = inFile.lines().iterator();
        while (it.hasNext()) {

            //Takes each line, separates into each word and stores into map and queue
            String str = it.next();
            while (str.length() > 0) {

                String word = nextWordorSeparator(str);
                if (word.equals(str)) {

                    str = str.substring(word.length(), str.length());
                } else {

                    str = str.substring(word.length() + 1, str.length());
                }
                if (!word.equals("")) {

                    //If map has the key, value gets incremented.
                    //Otherwise, value is newly added
                    if (map.containsKey(word)) {

                        map.replace(word, map.get(word) + 1);
                    } else {

                        map.put(word, 1);
                    }
                }
            }

        }

    }

    /**
     * Stores each word with the top n counts from a text file into an
     * alphabetized list of entries along with their respective counts.
     *
     * @param map
     *            the map that will contain all the words and their respective
     *            counts
     *
     * @param n
     *            the number of words in the tag cloud
     * @replaces sorted
     * @return alphabetized list
     *
     * @ensures <pre>
     * map = #map *
     *   [top n words and their respective counts within the text file]
     * sorted = #sorted *
     *   [all words within the map in alphabetical order]
     * </pre>
     */
    private static List<Entry<String, Integer>> parseForTopValues(
            Map<String, Integer> map, int n) {

        Comparator<Entry<String, Integer>> cmp = new MapPairLT();
        Comparator<Entry<String, Integer>> smp = new StringLT();
        List<Entry<String, Integer>> list = new LinkedList<Entry<String, Integer>>(
                map.entrySet());
        List<Entry<String, Integer>> listFinished = new LinkedList<Entry<String, Integer>>();

        Collections.sort(list, cmp);
        for (int i = 0; i < n && list.size() > 0; i++) {

            listFinished.add(list.remove(0));
        }
        Collections.sort(listFinished, smp);
        return listFinished;
    }

    /**
     * Distributes font size between 11 and 48 and is based on the count.
     */
    private static String fontSize(int count, int min, int max) {
        final int minFontSize = 11;
        final int maxFontSize = 48;

        double size = 0;
        size = (maxFontSize - minFontSize);
        double sizePart = ((double) count - (double) min)
                / ((double) max - (double) min);
        size *= sizePart;
        size += minFontSize;
        return "f" + (int) size;
    }

    /**
     * Generates an HTML page containing the words of an outside file and their
     * respective counts in a certain font size
     *
     * @param map
     *            the map containing the words and their counts
     * @param outFile
     *            the file to be taking from
     * @param inputLocation
     *            the file to be written to
     * @param sorted
     *            a sorted queue of the words
     *
     * @updates out.content
     * @requires out.is_open
     * @ensures <pre>
     * out.content = #out.content *
     *   [an HTML page containing the table with words and their counts]
     * </pre>
     */
    private static void generateHTML(List<Entry<String, Integer>> list,
            PrintWriter outFile, String inputLocation, int words) {

        int min = Integer.MAX_VALUE;
        int max = Integer.MIN_VALUE;
        for (Entry<String, Integer> list1 : list) {
            if (list1.getValue() < min) {

                min = list1.getValue();
            } else if (list1.getValue() > max) {

                max = list1.getValue();
            }
        }

        //Outputting html code
        outFile.println("<!DOCTYPE html>");
        outFile.println("<html>");
        outFile.println("<head>");
        outFile.println("<title>Top " + words + " words in " + inputLocation
                + "</title>");
        outFile.println(
                "<link href=\"tagcloud.css\" rel=\"stylesheet\" type=\"text/css\">");
        outFile.println("</head>");
        outFile.println("<body>");
        outFile.println(
                "<h2>Top " + words + " words in " + inputLocation + "</h2>");
        outFile.println("<hr>");
        outFile.println("<div class=\"cdiv\"><p class=\"cbox\">");

        for (int i = 0; i < list.size(); i++) {

            Entry<String, Integer> word = list.get(i);

            String font = fontSize(word.getValue(), min, max);

            outFile.print("<span class=\"" + font + "\" "
                    + "style=\"cursor:default\" title=\"count: "
                    + word.getValue() + "\">");
            outFile.print(word.getKey());
            outFile.println("</span>");

        }

        //Output html closing tags
        outFile.println("</p></div>");
        outFile.println("</body>");
        outFile.println("</html>");
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    @SuppressWarnings("resource")
    public static void main(String[] args) {
        //Initializing normal out and in streams
        BufferedReader inFile;
        PrintWriter outFile;
        //
        //Do we need a try catch here?
        Scanner sc = new Scanner(System.in);
        String inputLocation;

        try {
            //Gathers input and output files
            System.out.print("Enter the text file you wish to use: ");
            inputLocation = sc.nextLine();
            inFile = new BufferedReader(new FileReader(inputLocation));
        } catch (IOException e) {
            System.err.println("ERROR: Unable to open file");
            return;
        }
        try {
            System.out.print("Enter the file you wish to write to: ");
            String outputLocation = sc.nextLine();
            outFile = new PrintWriter(
                    new BufferedWriter(new FileWriter(outputLocation)));
        } catch (IOException e) {
            System.err.println("ERROR: Unable to create file");
            return;
        }
        System.out.print("Enter the number of words you wish to display: ");
        int n = sc.nextInt();

        //Initializing the main map and queue for this program
        Map<String, Integer> main = new HashMap();

        completeMap(main, inFile);
        List<Entry<String, Integer>> list = parseForTopValues(main, n);
        generateHTML(list, outFile, inputLocation, n);
        try {
            //Close input and output streams
            inFile.close();
            outFile.close();
        } catch (IOException e) {
            System.err.println("ERROR: Could not close file");
        }
    }

}